package com.capgemini.capstore.service;

import javax.validation.Valid;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;

public interface CapStoreServiceI {

	


	public Coupon getcoupon(Customer user);
	public double applycoupon(Customer user);
	public Coupon createcoupon( Coupon coupon) ;

}
