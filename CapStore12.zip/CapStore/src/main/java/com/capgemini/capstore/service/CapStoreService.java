package com.capgemini.capstore.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Cart;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.dao.IDAO;

@Service("service")
public class CapStoreService implements CapStoreServiceI{

	@Autowired
	private IDAO Dao;
	
	Cart cart=new Cart();
	Date date=new Date();
	
	
	public Coupon createcoupon(Coupon coupon) {
		Dao.save(coupon);
		return Dao.save(coupon);
			}

		public Coupon getcoupon(Customer user)
	   {		 
		 Coupon c = Dao.getcoupon(user);
		 if(c==null)
		 {
			 throw new RuntimeException( "Coupon not found"); 
		 }
		 else {
			 return c;
		 }
	     } 
		public double applycoupon(Customer user)
		{
			Coupon c = Dao.getcoupon(user);
			float discount=c.getDiscountPercent();
			double price=cart.getAmount();
			if(((c.getGenerationDate().compareTo(date))>0)&&((c.getExpiryDate().compareTo(date)))<0)
			{ 
				price=price-c.getDiscountPercent();
			cart.setAmount(price);
			return price;
			}
			else
			{
				throw new RuntimeException( "Coupon not found");		
		}}	
		
}