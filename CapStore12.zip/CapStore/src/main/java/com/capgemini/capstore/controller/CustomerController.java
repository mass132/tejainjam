package com.capgemini.capstore.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.service.CapStoreService;

@RestController
@RequestMapping(value="/coupon")
public class CustomerController {
	@Autowired CapStoreService service;
	
	
	@PostMapping("/create")
	public Coupon createcoupon( @RequestBody Coupon coupon)   {
		return service.createcoupon(coupon);
	}
	
	 @GetMapping(value="/check/{customerId}")	
	    public Coupon getbyid(@PathVariable @RequestBody Customer user) 
	 {
	        return service.getcoupon(user);
	    
	 }    
	    @GetMapping(value="/apply/{customerId}")	
	    public double findbycode(@PathVariable @RequestBody Customer user) {
	        return service.applycoupon(user);
	    }
}
