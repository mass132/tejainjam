package com.capgemini.capstore.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.beans.Customer;

@Repository
@Transactional
public interface IDAO extends JpaRepository<Coupon, String> {


	@Query("select Coupon c where c.user=?1")
	public Coupon getcoupon(Customer user);
	@Query("select c.discountPercent from Coupon c where c.user=?1")
	public float discountPercent(Customer user) ;
}


