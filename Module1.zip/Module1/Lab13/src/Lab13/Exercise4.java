package Lab13;
import java.util.Scanner;
	/*
	interface anyInterface{
		public String name = "";
		public void setName(String name);
	}
	public class Excersise4 {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter username");
			String uname = sc.nextLine();
			
			
			anyInterface ai = (String name) -> {
				this.name = name;
			};
		}
	}*/
	public class Exercise4{	
		Exercise4 getInstance()
		{
			Exercise4 obj=new Exercise4();
			return obj;
		}	
		public static void main(String[] args) {
			//get
		}		
	}

