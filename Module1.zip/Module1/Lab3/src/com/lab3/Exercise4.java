package com.lab3;
import java.util.Scanner;
public class Exercise4 {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	char ch[]=new char[10];
	System.out.println("enter string  :");
	ch=sc.next().toCharArray();
	int len=ch.length;
	int count=0,flag=0;
	for(int i=0;i<len;i++)
	{
		count=0;
		for(int j=0;j<len;j++)
		{
			if(ch[j]==ch[i])
				count++;
		for(int k=0;k<i;k++)
		{
			if(ch[k]==ch[i])
				flag=1;
		}
		}
			if(flag!=1)
			{
				System.out.println(ch[i]+":"+count);
				flag=0;
			}
		  }
	  }
	}

