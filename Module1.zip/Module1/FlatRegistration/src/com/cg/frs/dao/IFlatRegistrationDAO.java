package com.cg.frs.dao;

public interface IFlatRegistrationDAO {

}
