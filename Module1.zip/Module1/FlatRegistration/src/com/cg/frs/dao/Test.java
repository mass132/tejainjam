package com.cg.frs.dao;
import static org.junit.Assert.assertEquals;

public class Test {

public class CustomerBookingDaoTest {
	IFlatRegistrationDAO dao=new FlatRegistrationDAOImpl();
	FlatOwner =new FlatOwner(123,10288,101, "ac");
	CustomerBean bean = new CustomerBean(10288, "aravind", "7093117585", "chennai","a@gmail.com" ,bean1);
	@Test
	 public void A()
	{
		 long a= dao.addCustomerDetails( bean);
		 System.out.println(a);
		 assertEquals(10288, a);
	}
	 public void B()
		{
			 RoomBooking a1= dao.getBookingDetails(bean.getCustomerid()) ;
			 System.out.println(a1);
			 assertEquals(bean1, a1);
		}
	
}
