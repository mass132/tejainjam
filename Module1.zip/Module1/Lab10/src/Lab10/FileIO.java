package Lab10;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	public class FileIO {
	public static void main(String[] args) throws IOException {
	FileReader fr = new FileReader("newFile.txt");
	CopyDataThread cp = new CopyDataThread();
	int r = fr.read();
	int count = 0;
	while(r != -1) {
	r = fr.read();
	if(count > 9) {
	count = 0;
	Thread t = new Thread(cp);
	t.start();
	}
	count++;
	}
	}
	}

