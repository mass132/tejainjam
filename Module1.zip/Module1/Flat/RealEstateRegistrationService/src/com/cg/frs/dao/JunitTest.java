package com.cg.frs.dao;
	public class JunitTest {
		
		 =new Customer(12324,"trgyt","yhftgh",5454, "hdfh");
		 FlatRegistrationDAOImpl dao=new FlatRegistrationDAOImpl();
		@Test
	public	void getCustId1()
		{
			long custId=dao.insertCust();
			System.out.println(custId);
			assertEquals(12324, custId);
		}
	}
}
