package com.Lab8;
import java.util.Scanner;
import java.util.StringTokenizer;
public class Exercise1
{
     public static void main(String[] args)
{
	int sum=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter integers :");
	String s=sc.nextLine();
	sc.close();
	StringTokenizer st=new StringTokenizer(s," ");
	 while(st.hasMoreTokens()) {
		 String temp=st.nextToken();
		 System.out.println(temp);
		 sum+=Integer.parseInt(temp);
		 
		 }
	 System.out.println("sum is "+sum);
}
}