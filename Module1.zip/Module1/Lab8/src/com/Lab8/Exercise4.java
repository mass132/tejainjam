package com.Lab8;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Exercise4
{
	public static void main(String[] args) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		File f=new File("1234.txt");
		f.createNewFile();
		f.mkdir();
		FileWriter fw=new FileWriter("1234.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		bw.write(100);
		bw.write("pavan");
		bw.newLine();
		System.out.println("file name"+ " "+f.exists());
		System.out.println("file Readble"+ " "+f.canRead());
		System.out.println("file writable"+ " "+f.canWrite());
		System.out.println("file length of file"+ " "+f.length());
	}
}
