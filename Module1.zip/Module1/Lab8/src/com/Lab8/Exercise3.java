package com.Lab8;
import java.util.Scanner;
public class Exercise3 {
	public void count(String s) {
	int words=0,lines=1;
	s=s;
	char ch[]=s.toCharArray();
	int l=ch.length;
	for(int i=0;i<l-1;i++)
	{
		char a=ch[i];
	    char b=ch[i+1];
	    int c=0;
	    if((a>=65 && a<=90)||(a>=97 && a<=122))
			{
				c++;	
			}
			if(a==' '&& b!=' ') 
			{
				words++;
			}
			if(a=='\n')
			{
				lines++;
			}
				}
				System.out.println("characters :"+(l)+"\n words:" +words +"\nLines:"+lines);
			}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter string ");
	String s=sc.nextLine();
	Exercise3 e=new Exercise3();
	e.count(s);
	sc.close();
}
}
