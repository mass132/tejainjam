package com.Lab8;
import java.util.Scanner;
public class Exercise7 {
 public static void main(String[] args) {
	boolean valid=false;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the name");
	
	
	
	
	
	
}
}
