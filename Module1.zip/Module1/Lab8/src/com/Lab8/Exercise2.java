package com.Lab8;
import java.io.*;
public class Exercise2 {
	public void readRAF(){
		try {
			RandomAccessFile r=new RandomAccessFile("D:\\Users\\pyarravu\\Desktop\\Java\\Employee1\\abc.txt","r");
			String a;
			int Line=1;
			while((a=r.readLine())!=null ) {
				System.out.println(Line+")"+a);
				Line++;
			}
			r.close();
		}	

		catch(Exception e) {
			System.out.println(e);
		}
	}
	public static void main(String[] args) {
		Exercise2 e=new Exercise2();
		e.readRAF();
	}

}
