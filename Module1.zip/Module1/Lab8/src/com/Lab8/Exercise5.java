package com.Lab8;
import java.util.*;
public class Exercise5
{
      int p=0;
      boolean m11(String s)
      {
    	  int l=s.length();
    	  char[] c=s.toCharArray();
    	  for(int i=0;i<1;i++)
    	  {
    		  int a=c[i];
    		  int b=c[i+1];
    		  if(a<b)
    		  {
    			  p++;
    		  }
    	  }
    	  if(p==l-1)
    	  {
    		  return true; 		
    	  }
    	  else
    		 {
    			 return false;     		  }
      }

      public static void main(String[] args) {
		System.out.println("enter the string");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		Exercise5 e=new Exercise5();
		boolean e1=e.m11(s);
		System.out.println(e1);
	}
}
