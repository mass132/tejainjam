package com.bean;

public class Bean 
{
	String empname;
	float empsalary;
	int id;
	public Bean(String empname, float empsalary, int id) {
		super();
		this.empname = empname;
		this.empsalary = empsalary;
		this.id = id;
	}
	 public Bean() {
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public float getEmpsalary() {
		return empsalary;
	}
	public void setEmpsalary(float empsalary) {
		this.empsalary = empsalary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "[empname=" + empname + ", empsalary=" + empsalary + ", id=" + id + "]";}	
}
