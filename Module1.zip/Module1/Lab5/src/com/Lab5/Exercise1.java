package com.Lab5;
import java.util.Scanner;
public class Exercise1 {
public static void main(String[] args) {
	System.out.println("*********traffic light*********");
	System.out.println("1.Red");
	System.out.println("2.Yellow");
	System.out.println("3.Green");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();	
	switch(n) {
	case 1: 
		System.out.println("STOP");
		break;
	case 2:
		System.out.println("ready to go");
		break;
	case 3:
		System.out.println("Go");
		break;
	default:
		System.out.println("wrong selection");
	}
}
}
