package com.Lab5;

public class EmployeeException extends Exception 
{
      public EmployeeException()
      {
    	  
      }
	public String toString()
	{
		return "low salary";
	}
}

