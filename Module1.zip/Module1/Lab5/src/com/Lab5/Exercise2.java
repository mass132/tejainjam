package com.Lab5;
import java.util.Scanner;
public class Exercise2 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter n");
	int n=sc.nextInt();
	calculate.cal(n);	
}
}
class calculate{
	static void cal(int n) 
	{
		int a=1;
		int b=1;
		int c=0;
		for(int i=2;i<n;i++)
		{
			c=a+b;
			a=b;
			b=c;		
		}
		System.out.println(c);
		int pr=printFibonacci(n);
		System.out.println("\n"+pr);
	}
static int printFibonacci(int n) {
	if(n==0)
	{
		return 0;
	}
	else if(n==1)
	{
		return 1;
	}
	else {
		return printFibonacci(n-1)+printFibonacci(n-2);
	}
}
}
