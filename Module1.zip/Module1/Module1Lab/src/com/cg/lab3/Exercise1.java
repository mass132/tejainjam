package com.cg.lab3;
import java.util.Scanner;
public class Exercise1 {
  public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	int n=sc.nextInt();
	System.out.println("size of array");
	int a[]=new int[n];
	System.out.println("enter array");
	for(int i=0;i<n;i++)
	{
		a[i]=sc.nextInt();
	}

	System.out.println("enetr an array ");
	int s=getSecondSmallest(a,n);
	System.out.println("second smallest number is" +s);
   }
  public static int getSecondSmallest(int a[],int n)
  {
	  int i,j,temp;
	  for( i=0;i<n;i++) 
	  {
		  for(j=i+1;j<n;j++)
		  {
			  if(a[i]>a[j])
			  {
			  temp=a[i];
			  a[i]=a[j];
			  a[j]=temp;
			  }
		  }
	  } 
	  i=0;
	  return a[i+1];
	  
  }
}
