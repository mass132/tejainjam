package com.cg.lab2;
class JournalPaper extends WrittenItem{
	private int yearPublished;

	public JournalPaper() {
		// TODO Auto-generated constructor stub
	}
	
	public int getYearPublished() {
		return yearPublished;
	}

	public void setYearPublished(int yearPublished) {
		this.yearPublished = yearPublished;
	}
	
}