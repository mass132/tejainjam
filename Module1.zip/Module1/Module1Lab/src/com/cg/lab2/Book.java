package com.cg.lab2;
	class Book extends WrittenItem{
		@Override
		public String getAuthor() {
			// TODO Auto-generated method stub
			return super.getAuthor();
		}

		@Override
		public void setAuthor(String author) {
			// TODO Auto-generated method stub
			super.setAuthor(author);
		}

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return super.toString();
		}

		@Override
		public boolean equals(Object obj) {
			// TODO Auto-generated method stub
			return super.equals(obj);
		}

		public Book() {
			// TODO Auto-generated constructor stub
		}
	}

