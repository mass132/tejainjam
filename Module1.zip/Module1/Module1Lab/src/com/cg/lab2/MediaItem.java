package com.cg.lab2;

abstract class MediaItem extends Item{
	private String author;
	public MediaItem() {
		// TODO Auto-generated constructor stub
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
}