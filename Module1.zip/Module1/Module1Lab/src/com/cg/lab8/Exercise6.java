package com.cg.lab8;
	import java.text.ParseException;
	import java.time.LocalDate;
	import java.time.Period;
	import java.time.format.DateTimeFormatter;
	import java.util.Scanner;

	//Create a method to accept 
	//date and print the duration in days, 
	//months and years with regards to current system date.

	public class Exercise6 {
		public static void getDuration(String dateString) throws ParseException {
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date=LocalDate.parse(dateString,dtf);
			LocalDate today=LocalDate.now();
			Period period=Period.between(date, today);
			System.out.println("Duration is:\n" +period.getYears()+"years\n" +period.getMonths()+"months\n" +period.getDays()+"days\n");
			}

			public static void main(String[] args) throws ParseException {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter date in  DD/MM/YYYY format  ");
			String db=sc.next();
			Exercise6.getDuration(db);
			sc.close();
		}
	}


