package com.cg.lab5;
import java.util.Scanner;
	 class MyEx extends Exception
	 {
		 int b;
		 MyEx(int a)
		 {
			 b=a;
		 }
		 public String toString() 
		 {
		  return "invalid "+b;
		 }
	 }
     public   class Exercise5
		 {
			 void m1(int a) throws MyEx
			 {
				 if(a>15)
				 {
					 System.out.println("valid");
				 }
				 else
				 {
					 throw new MyEx(a);
				 }
		     }
	public static void main(String[] args) throws MyEx
	 {
				Scanner sc =new Scanner(System.in);
				System.out.println("enter age");
				int a=sc.nextInt();
				Exercise5 s=new Exercise5();
				s.m1(a);
				sc.close();

      }
	 }
