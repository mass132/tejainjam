package com.cg.lab9;
	import java.util.*;
	public class Excercise1 {
	public ArrayList getSorted(HashMap m) {
	Collection value = m.values();
	ArrayList ar = new ArrayList(value);
	Collections.sort(ar);
	return ar;
	}
	public static void main(String[] args) {
	HashMap hm = new HashMap();
	Excercise1 ex = new Excercise1();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter number of entry you want to put");
	int n = sc.nextInt();
	for(int i = 0;i < n;i++) {
	System.out.println("Enter key(should be integer)");
	int key = sc.nextInt();
	sc.nextLine();
	System.out.println("Enter value(should be String)");
	String value = sc.nextLine();
	hm.put(key,value);
	}
	System.out.println(ex.getSorted(hm));
	sc.close();
	}
	}

