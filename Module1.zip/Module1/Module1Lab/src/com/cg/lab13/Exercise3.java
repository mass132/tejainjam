package com.cg.lab13;
import java.util.Scanner;

	interface authenticateI{
		boolean checkAuthentication(String username,String password);
	}
	public class Exercise3 {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter username");
			String uname = sc.nextLine();
			System.out.println("Enter password");
			String upass = sc.nextLine();
			authenticateI lm = (String username,String password) -> {
				if(username.equals("capgemini") && password.equals("password")) {
					return true;
				}
				else {
					return false;
				}
			};
			System.out.println(lm.checkAuthentication(uname, upass));
		}

	}

