package com.cg.lab13;
import java.util.Scanner;
	interface addSpaceI{
		public String addSpace(String ip);
	}
	public class Exercise2 {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter String");
			String s = sc.nextLine();
			addSpaceI lm = (String st) -> {
				String sm = st.replace(""," ").trim();
				return sm;
			};
			System.out.println(lm.addSpace(s));
			sc.close();
		}
		
	}

