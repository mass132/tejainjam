package com.cg.lab13;
import java.util.Scanner;
interface factorialI{
	public int fact(int n);
	default int n2(int n) {
		return n *n;
	}
}
public class Exercise5 {
	static factorialI f ;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter integer");
		int num = sc.nextInt();
		sc.nextLine();
		
		f = (n) -> {
			if(n == 0) {
				return 1;
			}
			if(n == 1) {
				return 1;
			}
			else {
			return n * f.fact(n-1);
			//return calc;
			}
		};
		System.out.println(f.fact(num));	
}
}
	