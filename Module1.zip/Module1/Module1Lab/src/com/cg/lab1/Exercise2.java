package com.cg.lab1;
import java.util.Scanner;
public class Exercise2
{
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("enter n");
		int n=sc.nextInt();
		int diff=calculateDifference(n);
		System.out.println(diff);
     }
	static int calculateDifference(int n)
{
		int d=0;
		int d1=0,sq=0;
		int d2=0,sum=0;
		for(int i=0;i<=n;i++)
		{
			sq=i*i;;
			d1+=sq;
		}
		for(int i=0;i<=n;i++)
		{
			sum+=i;
		}
		d2=sum*sum;
		d=d1-d2;
		return d;

}
}