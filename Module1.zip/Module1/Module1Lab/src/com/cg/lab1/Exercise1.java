package com.cg.lab1;

import java.util.Scanner;
public class Exercise1 {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	System.out.println("enter n");
	int n=sc.nextInt();
	int sum=calculateSum(n);
	System.out.println(sum);
}
static int calculateSum(int n) {
	int sum=0;
	for(int i=0;i<=n;i++)
	{
		if(i%3==0||i%5==0) {
			sum+=i;
		}
	}
	return sum;
}
}
