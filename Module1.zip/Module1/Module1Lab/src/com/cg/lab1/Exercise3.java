package com.cg.lab1;
import java.util.Scanner;
public class Exercise3 
{
	static boolean checkNumber(int num)
	{
		int t;
		t=num;
		while(num>0)
		{
			t/=10;
			int n1=num%10;
			num/=10;
			int n2=num%10;
			if(n2>n1)
			{
				return false;
			}
		}
			return true;
	}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter n ");
	int num=sc.nextInt();
	Exercise3 p=new Exercise3();
	p.checkNumber(num);
	if(checkNumber(num))
	{
		System.out.println("increasing order");
	}
	else 
	{
		System.out.println("not increasing");
	}
	
}
}
