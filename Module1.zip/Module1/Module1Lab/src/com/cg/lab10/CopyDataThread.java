package com.cg.lab10;
public class CopyDataThread implements Runnable{
		@Override
		public void run() {
		// TODO Auto-generated method stub
		try {
		Thread.sleep(2000);
		} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		}
		}

