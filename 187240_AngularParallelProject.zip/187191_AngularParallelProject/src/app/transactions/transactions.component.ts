import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/Models/Transactions';
import { Customer } from 'src/Models/Customer';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  transactions:Transactions[]=[];
  customers:Customer[]=[];
  service:ServiceService;
  router:Router;

  constructor(service:ServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  miniStatement(data:any){
    this.transactions=this.service.miniStatement(data.caccount);
    
  }

  ngOnInit() {
    this.service.fetchTransactions();
    this.customers=this.service.getCustomers();
  }


}
