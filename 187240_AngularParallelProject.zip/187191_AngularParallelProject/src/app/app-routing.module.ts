import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { CashTransferComponent } from './cash-transfer/cash-transfer.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { ViewComponent } from './view/view.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';


const routes: Routes =
 [
  {path:'login',
  component:LoginComponent},
  {path:'signup',
  component:SignUpComponent},
  {path:'view',
  component:ViewComponent},

{path:'balance',
component:ShowBalanceComponent},
{path:'deposit',
component:DepositComponent},
{path:'withdraw',
component:WithdrawComponent},
{path:'cashtransfer',
component:CashTransferComponent},
{path:'transactions',
component:TransactionsComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
