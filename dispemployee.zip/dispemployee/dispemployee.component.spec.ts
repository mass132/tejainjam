import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DispemployeeComponent } from './dispemployee.component';

describe('DispemployeeComponent', () => {
  let component: DispemployeeComponent;
  let fixture: ComponentFixture<DispemployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DispemployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DispemployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
