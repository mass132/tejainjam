import { Component, OnInit } from '@angular/core';
import { Employee } from '../empservice.service';
import {EmpserviceService} from '../empservice.service';

@Component({
  selector: 'dispemployee',
  templateUrl: './dispemployee.component.html',
  styleUrls: ['./dispemployee.component.css']
})
export class DispemployeeComponent implements OnInit {
service:EmpserviceService;
 
    constructor(service:EmpserviceService) {
      this.service=service;
      }
      employees:Employee[]=[]
      delete(firstname:string)
      {
            
           this.service.delete(firstname);
          this.employees=this.service.getEmployees();
    
      }
      sortfirstname(){
        this.employees=this.service.name2();
      }
  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
