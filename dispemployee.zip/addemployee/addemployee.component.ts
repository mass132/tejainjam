import { Component, OnInit } from '@angular/core';
import { Employee, EmpserviceService } from '../empservice.service';

@Component({
  selector: 'addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
  createdEmployee:Employee;
  createdFlag:boolean=false;
  service:EmpserviceService;
  constructor(service:EmpserviceService) {
    this.service=service;
   }
  ngOnInit() {

  }
add(data:any){
  this.createdEmployee=new Employee(data.firstname, data.lastname,data.sal,data.gender,data.contact);
  this.service.add(this.createdEmployee);
  this.createdFlag=true;
}

}
