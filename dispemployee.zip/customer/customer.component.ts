import { Component, OnInit } from '@angular/core';
import {customerService, Employee} from '../customer.service';

@Component({
  selector: 'customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  service:customerService;
 
  constructor(service:customerService) {
    this.service=service;

    }
    employees:Employee[]
sortid(){
  this.employees=this.service.id1();
  
}
sortname(){
  this.employees=this.service.name1();
}

  delete(dptId:number)
  {
        
       this.service.delete(dptId);
      this.employees=this.service.getEmployees();

  }
ngOnInit() {
  this.service.fetchEmployees();
  this.employees=this.service.getEmployees();
}
}



