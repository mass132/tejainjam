import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MusicstoreService {
  http:HttpClient;
  albums:Music[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchAlbums();
  }

  fetched:boolean=false;

  fetchAlbums()
  {
    this.http.get('./assets/Album.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getAlbums():Music[]
  {
    return this.albums;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Music(o.AlbumID,o.Title,o.Artist,o.Price);
      this.albums.push(e);
    }
  }
  
  delete(AlbumID:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.albums.length;i++)
    {
      let e=this.albums[i];
      if(AlbumID==e.AlbumID)
      {
        foundIndex=i;
        break;
      }
    }
    this.albums.splice(foundIndex,1);
  }

  add(e:Music){
    this.albums.push(e);
  }
}

export class Music{
  AlbumID:number;
  Title:string;
  Artist:string;
  Price:number;
 
    constructor(AlbumID:number,Title:string, Artist:string,Price:number)

    {
      this.AlbumID=AlbumID
      this.Title=Title;
      this.Artist=Artist;
      this.Price=Price;
      
    }
}