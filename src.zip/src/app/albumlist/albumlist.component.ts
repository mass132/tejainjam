import { Component, OnInit } from '@angular/core';
import { Music, MusicstoreService } from '../musicstore.service';

@Component({
  selector: 'app-albumlist',
  templateUrl: './albumlist.component.html',
  styleUrls: ['./albumlist.component.css']
})
export class AlbumlistComponent implements OnInit {
  service:MusicstoreService;
  constructor(service:MusicstoreService) { 
    this.service=service;
  }

   albums:Music[]=[];
  delete(eid:number)
 {
   this.service.delete(eid);
     this.albums=this.service.getAlbums();
     alert("Are you sure want to delete");
  }
  ngOnInit() {
    this.service.fetchAlbums();
    this.albums=this.service.getAlbums();
  }
}
