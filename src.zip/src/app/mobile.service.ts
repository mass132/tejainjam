import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MobileService {

  http:HttpClient;
  mobiles:Mobile[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchmobiles();
  }

  fetched:boolean=false;

  fetchmobiles()
  {
    this.http.get('./assets/mobile.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  getmobiles():Mobile[]
  {
    return this.mobiles;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Mobile(o.mobid,o.mobname,o.mobprice);
      this.mobiles.push(e);
    }
  }
  
  delete(mobid:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.mobiles.length;i++)
    {
      let e=this.mobiles[i];
      if(mobid==e.mobid)
      {
        foundIndex=i;
        break;
      }
    }
    this.mobiles.splice(foundIndex,1);
  }

  add(e:Mobile){
    this.mobiles.push(e);
  }

  update(data:Mobile)
  {
    let mobid=data.mobid;
    for(let i=0;i<this.mobiles.length;i++)
    {
      if(mobid === this.mobiles[i].mobid)
      {
        this.mobiles[i].mobname=data.mobname;
        this.mobiles[i].mobprice=data.mobprice;   
        break;
      }
    }
  }
}

export class Mobile{
  mobid:number;
mobname:string;
  mobprice:number;
  
    constructor(mobid:number,mobname:string,mobprice:number)
    {
      this.mobid=mobid;
      this.mobname=mobname;
      this.mobprice=mobprice
    }
}

