import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MobileService, Mobile } from '../mobile.service';
@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css']
})
export class MobileComponent implements OnInit {
  service:MobileService;
  constructor(service:MobileService) { 
    this.service=service;
  }
  mobiles:Mobile[]=[];
  delete(mobid:number)
  {
    this.service.delete(mobid);
    this.mobiles=this.service.getmobiles();
    console.log("aa");
  }

  isUpdate:boolean=true;
  updateData()
  {
    this.isUpdate=!this.isUpdate;
  }
  update(data:any)
  {
    this.service.update(data);
    this.mobiles=this.service.getmobiles();
  }

  column:string="mobid"; 
  order:boolean=true;

  sort(column:string)
  {    
    if(this.column==column )
    {
      this.order=!this.order;
    }
    else
    {
      this.order=true;
      this.column=column;
    }
  }
  ngOnInit() {
    this.service.fetchmobiles();
    this.mobiles=this.service.getmobiles();
  }
}

  