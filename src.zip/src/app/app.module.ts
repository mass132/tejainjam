import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MobileComponent } from './mobile/mobile.component';
import { MobilePipe } from './mobile.pipe';
import { MobileService } from './mobile.service';

@NgModule({
  declarations: [
    AppComponent,
    MobileComponent,
    MobilePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,
  ],
  providers: [HttpClient,MobileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
