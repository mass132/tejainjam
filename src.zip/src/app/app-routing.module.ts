import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AddalbumComponent} from './addalbum/addalbum.component';
import { AlbumlistComponent } from './albumlist/albumlist.component';

const routes: Routes = [
{
  path:'app-addalbum',
  component : AddalbumComponent
},
{
  path:'app-albumlist',
  component : AlbumlistComponent
}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
