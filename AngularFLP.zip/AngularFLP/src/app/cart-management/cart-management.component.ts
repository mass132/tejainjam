import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-management',
  templateUrl: './cart-management.component.html',
  styleUrls: ['./cart-management.component.css']
})
export class CartManagementComponent implements OnInit {
  title = 'plp';
  constructor() { }

  ngOnInit() {
  }

}
