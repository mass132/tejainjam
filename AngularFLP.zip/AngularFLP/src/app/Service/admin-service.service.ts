import { Injectable } from '@angular/core';

import { Product } from '../Entity/Product';
import { HttpClient } from '@angular/common/http';
import { Merchant } from '../entity/Merchant';


import { Category } from '../Entity/Category';
import { Observable } from 'rxjs';
import { Customer } from '../Entity/customer';
import { Data } from '../Entity/Data';
import { Coupon } from '../Entity/Coupon';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {
  product:Product[]=[];
  merchant:Merchant[]=[];
 customer:Customer[]=[];
 category:Category[]=[];
 datas:Data[]=[];
 coupon:Coupon[]=[];
 deliveryStatus:any[]= [];
 url:string = "http://10.138.150.144:9676/admin/";
  constructor(private http:HttpClient) {
   }
   private handleError(error: any): Promise<any> {
    return Promise.reject(error.error || error);
  }
   //Delivery Status
fetchDeliveryStatus(type:string):Promise<any>{
    return this.http.get(this.url+'/deliverystatus/'+type)
      .toPromise()
      .then(response => response)
      .catch(this.handleError);
}


   //product
   fetchedProduct:boolean=false;
   fetchProduct(){
     this.http.get('./assets/product.json').subscribe(
       data=>{
         if(!this.fetchedProduct){
           this.convertProduct(data);
           this.fetchedProduct=true;
         }
       }
     );
 }
 getProduct():Product[]{
   return this.product;
 }
 convertProduct(data:any){
   for(let o of data["product"]){
     let e=new Product(o.productId,o.productDescription,o.productDiscount,o.productName,o.productPrice,o.productQuantity);
     this.product.push(e); //fetching details from json class and pushing the value inside table
   }
 }
 deleteProduct(productId:number){
   let foundIndex:number=-1;
   for(let i=0;i<this.product.length;i++){
     let e=this.product[i];
     if(productId==e.productId){
       foundIndex=i;
       break;
 
     }
   }
   this.product.splice(foundIndex,1); //To delete the details splice method is used
 }
 addProduct(e:Product){ //add method is used to add the details
    
   this.product.push(e);
     }

     updateProduct(e:Product){
       for(let i=0;i<this.product.length;i++){
         if(e.productId==this.product[i].productId){
          this.product[i].productDescription=e.productDescription;
          this.product[i].productDiscount=e.productDiscount;
           this.product[i].productName=e.productName;
           this.product[i].productPrice=e.productPrice;
           this.product[i].productQuantity=e.productQuantity;
          
           break;
         }
       }
}
searchProduct(productName:string):Product[]
  {
    let result:Product[]=[];
    let o:Product
    var flag=0;
    for(let i=0;i<this.product.length;i++)
    {
      o=this.product[i];
      if(productName==o.productName)
      {
        result.push(o);
        flag=1;
      }
    }
    if(flag==0)
    {
      alert(productName +".....Record Not Found");
    }
    return result;
  }


//merchant
  showMerchant():Observable<any>{
    return this.http.get('http://localhost:9676/merchant/showAll');
  }

  add(e:Merchant):Observable<any>{
    return this.http.post("http://localhost:9676/merchant/add",e);

  }
  update(merchantId:number,e:Merchant):Observable<any>{
    return this.http.put("http://localhost:9676/merchant/update/"+merchantId+"/",e);
  }

  //ThirdParty
  addThird(e:Merchant):Observable<any>{
    return this.http.post("http://localhost:9676/merchant/add",e);
  }
  ThirdShow():Observable<any>{
    return this.http.get('http://localhost:9676/merchant/showAll');
  }
fetchedMerchant:boolean=false;
  fetchMerchant(){
    this.http.get('./assets/merchant.json')//path for json file
    .subscribe(
      data=>
      {
        if(!this.fetchedMerchant)
        {
          this.convertMerchantData(data);
          this.fetchedMerchant=true;
        }
      }
    );
  }
  getMerchantData():Merchant[]{
    return this.merchant;
  }
  convertMerchantData(data:any){
    for(let m of data){
      let merchantDetails=new Merchant(m.merchantId,m.merchantAnswer,m.merchantCompanyName,m.merchantContactNo,m.merchantDiscount,m.merchantGSTNo,m.merchantName,m.merchantPassword,m.merchantQuestion,m.merchantStatus)
      this.merchant.push(merchantDetails);
    }
   
  }
  searchMerchant(merchantName:string):Merchant[]
    {
      let result:Merchant[]=[];
      let o:Merchant
      var flag=0;
      
      for(let i=0;i<this.merchant.length;i++)
      {
        o=this.merchant[i];
        if(merchantName==o.merchantName)
        {
          result.push(o);
          flag=1;
        }
        
      }
      if(flag==0)
      {
        alert(merchantName +".....Record Not Found");
      }
      return result;
    }




//Customer
  fetchedCustomer:boolean=false;
  fetchCustomerData(){
   this.http.get('./assets/customer.json')//path for json file
   .subscribe(
     data=>
     {
       if(!this.fetchedCustomer)
       {
         this.convertCustomerData(data);
         this.fetchedCustomer=true;
       }
     }
   );
 }
getCustomerData():Customer[]{
 return this.customer;
}
convertCustomerData(data:any){
 for(let c of data){
   let customerDetails=new Customer(c.customerId,c.customerAddress,c.customerAnswer,c.customerContactNo,c.customerName,c.customerPassword,c.customerQuestion,c.customerStatus)
this.customer.push(customerDetails);
 }
}

searchCustomer(customerName:string):Customer[]
  {
    let result:Customer[]=[];
    let o:Customer
    var flag=0;
    for(let i=0;i<this.customer.length;i++)
    {
      o=this.customer[i];
      if(customerName==o.customerName)
      {
        result.push(o);
        flag=1;
      }
    }
    if(flag==0)
    {
      alert(customerName +".....Record Not Found");
    }
    return result;
  }



  //Category
  fetchedCategory:boolean=false;
  fetchCategory(){
    this.http.get('./assets/category.json').subscribe(
      data=>{
        if(!this.fetchedCategory){
          this.convertCategory(data);
          this.fetchedCategory=true;
        }
      }
    );
}
getCategory():Category[]
{
  
  return this.category;
}
convertCategory(data:any){
  for(let o of data["category"]){
    let e=new Category(o.categoryId,o.categoryGender,o.categoryType);
    this.category.push(e); //fetching details from json class and pushing the value inside table
  }
}
deleteCategory(categoryId:number){
  let foundIndex:number=-1;
  for(let i=0;i<this.category.length;i++){
    let e=this.category[i];
    if(categoryId==e.categoryId){
      foundIndex=i;
      break;

    }
  }
  this.category.splice(foundIndex,1); //To delete the details splice method is used
}
addCategory(e:Category){ //add method is used to add the details
   
  this.category.push(e);
    }
    updateCategory(e:Category){
      for(let i=0;i<this.category.length;i++){
        if(e.categoryId==this.category[i].categoryId){
          this.category[i].categoryGender=e.categoryGender;
          this.category[i].categoryType=e.categoryType;
         
          break;
        }
      }
}
searchCategory(categoryType:string):Category[]
{
  let result:Category[]=[];
  let o:Category
  var flag=0;
  for(let i=0;i<this.category.length;i++)
  {
    o=this.category[i];
    if(categoryType==o.categoryType)
    {
      result.push(o);
      flag=1;
    }
  }
  if(flag==0)
  {
    alert(categoryType +".....Record Not Found");
  }
  return result;
}

//feedback

fetchedFeedback:boolean=false;
fetchFeedback(){
 return this.http.get("../../assets/feed.json");
}


//Delivery Status
fetchedDelivery:boolean=false;

  fetchDatas()
  {
    this.http.get('./assets/Data.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetchedDelivery)
        {
          this.convert(data);
          this.fetchedDelivery=true;
        }
      }
    );
  }
  getDatas():Data[]
  {
    return this.datas;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Data(o.productId,o.productName,o.productDescription,o.productQuantity,o.productPrice);
      this.datas.push(e);
    }
  }

  //Discount
  createCoupon:Coupon;
   GenerateCoupon(data:any){
     this.createCoupon=new Coupon(data.couponId,data.couponCode,data.minAmount,data.maxAmount,data.discountPercent,data.generationDate,data.expiryDate);
   
   
    alert('Coupon Generated Successfully!! :-)\n\n');
  }
  
}

