import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Merchant } from 'src/app/entity/Merchant';

@Component({
  selector: 'app-show-party',
  templateUrl: './show-party.component.html',
  styleUrls: ['./show-party.component.css']
})
export class ShowPartyComponent implements OnInit {
  merchant:Merchant[]=[];
  service:AdminServiceService;

 constructor(service:AdminServiceService) { 
   this.service=service;

   this.showThird();
    }
 showThird(){
   var mini = this.service.ThirdShow();
   mini.subscribe((data)=>{
     this.merchant=data
     console.log(this.merchant)
   })
 }
 ngOnInit() {
 }

}
