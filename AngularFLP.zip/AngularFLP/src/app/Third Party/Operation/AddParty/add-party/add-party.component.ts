import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/entity/Merchant';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-add-party',
  templateUrl: './add-party.component.html',
  styleUrls: ['./add-party.component.css']
})
export class AddPartyComponent implements OnInit {

  merchant:Merchant;
  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  addThird(data:any)
  {
    this.merchant = new Merchant(0,null,data.merchantCompanyName,data.merchantContactNo,0,null,data.merchantName,null,0,0);
      var sahu =this.service.addThird(this.merchant);
      sahu.subscribe( (data) => {
        console.log(data)
        alert("Added Succesfully!!! Merchant Id is : "+data.merchantId);
      })
  }
}
