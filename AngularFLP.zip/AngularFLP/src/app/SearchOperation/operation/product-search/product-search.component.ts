import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Product } from 'src/app/Entity/Product';



@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {
service:AdminServiceService;
  constructor(service:AdminServiceService) 
  {
    this.service=service;
   }
   product:Product[]=[];

  ngOnInit() {
    this.service.fetchProduct();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  searchProduct(data:any)
  {
    let name:string=data.productName;
    this.product=this.service.searchProduct(name);
  }
}
