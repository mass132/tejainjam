import { Component, OnInit } from '@angular/core';

import { Category } from 'src/app/Entity/Category';
import { AdminServiceService } from 'src/app/Service/admin-service.service';



@Component({
  selector: 'app-category-search',
  templateUrl: './category-search.component.html',
  styleUrls: ['./category-search.component.css']
})
export class CategorySearchComponent implements OnInit {
service:AdminServiceService;

  constructor(service:AdminServiceService) {
    this.service=service;
   }
category:Category[]=[];
  ngOnInit() {
    this.service.fetchCategory();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  searchCategory(data:any)
  {
    let name:string=data.categoryType;
    this.category=this.service.searchCategory(name);
  }
}
