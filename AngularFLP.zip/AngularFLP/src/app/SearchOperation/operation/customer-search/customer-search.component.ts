import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Customer } from 'src/app/Entity/customer';


@Component({
  selector: 'app-customer-search',
  templateUrl: './customer-search.component.html',
  styleUrls: ['./customer-search.component.css']
})
export class CustomerSearchComponent implements OnInit {
service:AdminServiceService;
  constructor(service:AdminServiceService)
   {
     this.service=service;
    }
customer:Customer[]=[];
  ngOnInit() {
    this.service.fetchCustomerData();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  searchCustomer(data:any)
  {
    let name:string=data.customerName;
    this.customer=this.service.searchCustomer(name);
  }
}
