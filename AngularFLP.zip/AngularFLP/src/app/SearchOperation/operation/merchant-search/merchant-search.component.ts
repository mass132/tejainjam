import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Merchant } from 'src/app/entity/Merchant';


@Component({
  selector: 'app-merchant-search',
  templateUrl: './merchant-search.component.html',
  styleUrls: ['./merchant-search.component.css']
})
export class MerchantSearchComponent implements OnInit {
service:AdminServiceService;

  constructor(service:AdminServiceService) {
    this.service=service;
   }
merchant:Merchant[]=[];
  ngOnInit() {
    this.service.fetchMerchant();
  }
  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  searchMerchant(data:any)
  {
    let name:string=data.merchantName;
    this.merchant=this.service.searchMerchant(name);
    
  }
}
