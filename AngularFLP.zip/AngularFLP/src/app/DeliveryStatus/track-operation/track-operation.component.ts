import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-track-operation',
  templateUrl: './track-operation.component.html',
  styleUrls: ['./track-operation.component.css']
})
export class TrackOperationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
