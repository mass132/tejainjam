import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Data } from 'src/app/Entity/Data';


@Component({
  selector: 'app-all-returned-products',
  templateUrl: './all-returned-products.component.html',
  styleUrls: ['./all-returned-products.component.css']
})
export class AllReturnedProductsComponent implements OnInit {

 
  service:AdminServiceService;
  constructor(service:AdminServiceService) { this.service=service}
  dataa:Data[]=[];
  ngOnInit() {
    this.service.fetchDatas();
    this.dataa=this.service.getDatas();
  }

}
