import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllShippedProductsComponent } from './all-shipped-products.component';

describe('AllShippedProductsComponent', () => {
  let component: AllShippedProductsComponent;
  let fixture: ComponentFixture<AllShippedProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllShippedProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllShippedProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
