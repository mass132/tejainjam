import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
import { Data } from 'src/app/Entity/Data';


@Component({
  selector: 'app-all-shipped-products',
  templateUrl: './all-shipped-products.component.html',
  styleUrls: ['./all-shipped-products.component.css']
})
export class AllShippedProductsComponent implements OnInit {

  service:AdminServiceService;
  constructor(service:AdminServiceService) { this.service=service}
  dataa:Data[]=[];
  ngOnInit() {
    this.service.fetchDatas();
    this.dataa=this.service.getDatas();
  }

 

}
