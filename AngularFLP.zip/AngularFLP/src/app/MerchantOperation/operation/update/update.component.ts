import { Component, OnInit } from '@angular/core';
import { Merchant } from 'src/app/entity/Merchant';
import { AdminServiceService } from 'src/app/Service/admin-service.service';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  merchant:Merchant;
  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  update(data:any)
  {
    this.merchant = new Merchant(data.merchantId,data.merchantAnswer,data.merchantCompanyName,data.merchantContactNo,data.merchantDiscount,data.merchantGSTNo,data.merchantName,data.merchantPassword,data.merchantQuestion,data.merchantStatus);
      var sahu =this.service.update(data.merchantId,this.merchant);
      sahu.subscribe((data) =>{
        console.log(data)
        alert("Updated successfully for merchant ID "+data.merchantId);
      })
  }
}


