import { Component, OnInit } from '@angular/core';

import { Merchant } from 'src/app/entity/Merchant';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  merchant:Merchant;
  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  add(data:any)
  {
    this.merchant = new Merchant(data.merchantId,data.merchantAnswer,data.merchantCompanyName,data.merchantContactNo,data.merchantDiscount,data.merchantGSTNo,data.merchantName,data.merchantPassword,data.merchantQuestion,data.merchantStatus);
      var sahu =this.service.add(this.merchant);
      sahu.subscribe( (data) => {
        console.log(data)
        alert("Added Succesfully!!! Merchant Id is : "+data.merchantId);
      })
  }
}
