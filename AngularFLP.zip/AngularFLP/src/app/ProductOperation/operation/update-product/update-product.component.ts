import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
  createdProduct:Product;

  createdFlag:boolean=false;

  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  updateProduct(data:any){
    this.createdProduct=new Product(data.productId,data.productDescription,data.productDiscount,data.productName,data.productPrice,data.productQuantity);
    this.service.updateProduct(this.createdProduct);
    this.createdFlag=true;
   }
}
