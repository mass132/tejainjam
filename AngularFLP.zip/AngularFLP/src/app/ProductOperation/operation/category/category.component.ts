import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/Entity/Category';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  service:AdminServiceService;
  constructor(service:AdminServiceService) {
    this.service=service;
   }
   category:Category[]=[];
   deleteCategory(categoryId:number){            
     this.service.deleteCategory(categoryId);
     this.category=this.service.getCategory();
   }
  ngOnInit() {
    this.service.fetchCategory();
    this.category=this.service.getCategory();
   
  }

}
