import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { AdminServiceService } from 'src/app/Service/admin-service.service';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  product:Product[]=[];
deleteProduct(productId:number){            
  this.service.deleteProduct(productId);
  this.product=this.service.getProduct();
}
  ngOnInit() {
    this.service.fetchProduct();
    this.product=this.service.getProduct();
  }

}
