import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Entity/Product';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  createdProduct:Product;
  createdFlag:boolean=false;
  service: AdminServiceService;
  constructor(service: AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  addProduct(data:any){  //This method is used to add the details 
    this.createdProduct=new Product(data.productId,data.productDescription,data.productDiscount,data.productName,data.productPrice,data.productQuantity);
    this.service.addProduct(this.createdProduct); 

    this.createdFlag=true;
  }
}
