import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/Entity/Category';
import { AdminServiceService } from 'src/app/Service/admin-service.service';

@Component({
  selector: 'app-update-category',
  templateUrl: './update-category.component.html',
  styleUrls: ['./update-category.component.css']
})
export class UpdateCategoryComponent implements OnInit {
  createdCategory:Category;

  createdFlag:boolean=false;

  service:AdminServiceService;
  constructor(service:AdminServiceService) { 
    this.service=service;
  }

  ngOnInit() {
  }
  updateCategory(data:any){
    this.createdCategory=new Category(data.categoryId,data.categoryGender,data.categoryType);
    this.service.updateCategory(this.createdCategory);
    this.createdFlag=true;
   }
}
