import { Component, OnInit } from '@angular/core';
import { Category } from 'src/app/Entity/Category';
import { AdminServiceService } from 'src/app/Service/admin-service.service';



@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {
  createdCategory:Category;
  createdFlag:boolean=false;
  service: AdminServiceService;
  constructor(service: AdminServiceService) {
    this.service=service;
   }

  ngOnInit() {
  }
  addCategory(data:any){  //This method is used to add the details 

    this.createdCategory=new
    Category(data.categoryId,data.categoryGender,data.categoryType);
    this.service.addCategory(this.createdCategory); 
    this.createdFlag=true;
  }
}
