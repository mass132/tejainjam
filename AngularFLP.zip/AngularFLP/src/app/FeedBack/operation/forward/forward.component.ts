import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forward',
  templateUrl: './forward.component.html',
  styleUrls: ['./forward.component.css']
})
export class ForwardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
