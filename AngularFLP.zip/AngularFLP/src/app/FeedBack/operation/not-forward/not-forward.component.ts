import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-forward',
  templateUrl: './not-forward.component.html',
  styleUrls: ['./not-forward.component.css']
})
export class NotForwardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
