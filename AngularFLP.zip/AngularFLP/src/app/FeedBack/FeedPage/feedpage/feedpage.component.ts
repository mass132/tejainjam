import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedpage',
  templateUrl: './feedpage.component.html',
  styleUrls: ['./feedpage.component.css']
})
export class FeedpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
