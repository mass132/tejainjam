function msg(){
    document.write("pavan java script");
}