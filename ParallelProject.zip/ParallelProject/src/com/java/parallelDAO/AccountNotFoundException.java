package com.java.parallelDAO;
public class AccountNotFoundException extends RuntimeException{
	public  AccountNotFoundException(String s) {
		super(s);
	}
}
