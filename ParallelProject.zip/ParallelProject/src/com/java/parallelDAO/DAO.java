package com.java.parallelDAO;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import com.java.parallelBean.Bean;
import com.java.parallelBean.TransBean;
public class DAO implements DAOI {
	long bacc;
	long dep2;
	long w2,q1,q2;
	long i=10000;
	long bal;
	EntityManager em;
	public DAO() {
		em = JPAUtil.getEntityManager();
	}
	//ArrayList<TransBean> a1;
	
	public long createaccount(Bean b) {
		this.bacc=b.getBacc();
		em.persist(b);
		return bacc;		
	}
	public long showbalance(long bacc2,String password1) {	
		TypedQuery<Bean> TQ=em.createQuery("select p from Bean p",Bean.class);
		List<Bean> st=TQ.getResultList();
        for(Bean i:st)
        {
            if(bacc2==i.getBacc()&& (password1.equals(i.getBacc())))
            {
                bal= i.getBal();
            }else {
                throw new AccountNotFoundException("enter valid account number or password");
            }
        }
        return bal;

	}
	
	public long deposit1(long account2, String password2, long dep1) {
		TypedQuery<Bean> tq=em.createQuery("select pavan from Bean pavan",Bean.class);
        List<Bean> st=tq.getResultList();
        for(Bean q1:st)
        {
            if(account2==q1.getBacc()&& (password2.equals(q1.getPassword())))
            {
            dep2=dep1+q1.getBal();
            }else {
                throw new AccountNotFoundException("enter valid account number or password");
            }
        }
        
        Query q=em.createQuery("update Bean set Account No = account2 where Balance = dep1 ");
        q.executeUpdate();       
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        TransBean tb = new TransBean();
        tb.setAccountnumber(account2);
        tb.setTransdate(formatter.format(date));
        tb.setAmount(bal);
        tb.setTransid(++i);  
        tb.setTranstype("deposit");              
        return dep2;
    }
		
	public long withdraw(long account3, String password3, long w1) {	
		
		TypedQuery<Bean> tq=em.createQuery("select pavan from Bean pavan",Bean.class);
        List<Bean> st=tq.getResultList();
        for(Bean q1:st)
        {
            if(account3==q1.getBacc()&& (password3.equals(q1.getPassword())))
            {
            w2=w1+q1.getBal();
            }else {
                throw new AccountNotFoundException("enter valid account number or password");
            }
        }
        
        Query q=em.createQuery("update Bean set Account No = account3 where bal = w1 ");
        q.executeUpdate();       
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        TransBean tb = new TransBean();
        tb.setAccountnumber(account3);
        tb.setTransdate(formatter.format(date));
        tb.setAmount(bal);
        tb.setTransid(++i);  
        tb.setTranstype("withdraw");              
        return w2;
    }
public int fund1(long account4, long account5, String password4, int f1) {
        
        TypedQuery<Bean> tq=em.createQuery("select ar from Bean ar",Bean.class);
        List<Bean> st=tq.getResultList();
        for(Bean q1:st)
        {
            if(account4==q1.getBacc() && (password4.equals(q1.getPassword())) && account4==q1.getBacc())
            {
            	q1=
        		q2=bal2.getBal()+f1;
            }else {
                throw new AccountNotFoundException("enter valid account numbers or password");
            }
        }
        
        Query q=em.createQuery("update Bean set Account No = account4 where Balance = q1");
        q.executeUpdate();    
        Query q=em.createQuery("update Bean set Account No = account5 where Balance = q2");
        q3.executeUpdate();    
       return q1;
    }
	
	public boolean validation(long account4, String password4) {
		if(hm1.containsKey(account4));
		{
			Bean b=(Bean) hm1.get(account4);
					if(b.getPassword().equals(password4)) {
						return true;
					}
		}
		return false;
	}
	public boolean validation1(long account4, String password4, long account5) {
		if(hm1.containsKey(account4)&&hm1.containsKey(account5));
		{
			Bean b=(Bean) hm1.get(account4);
					if(b.getPassword().equals(password4)) {
						return true;
					}
		}
		return false;
	}
	
	public List<TransBean> trans() {
		List<TransBean> a1=new ArrayList<TransBean>(hmt.keySet());
		return a1;
	}
	@Override
	public long service1(Bean b) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public long fund(long account4, long account5, String password4, long f1) {
		// TODO Auto-generated method stub
		return 0;
	}
	

	}
	
	
	

