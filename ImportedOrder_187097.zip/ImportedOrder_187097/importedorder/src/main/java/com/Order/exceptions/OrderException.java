package com.Order.exceptions;

import java.util.Date;

public class OrderException {

	  private Date timestamp;

	  private String message;

	  private String details;

	  private String httpCodeMessage;

	  public OrderException(Date timestamp, String message, String details,String httpCodeMessage) {

	    super();

	    this.timestamp = timestamp;

	    this.message = message;

	    this.details = details;

	    this.httpCodeMessage=httpCodeMessage;

	  }

	  public String getHttpCodeMessage() {

	    return httpCodeMessage;

	  }

	  public Date getTimestamp() {

	    return timestamp;

	  }

	  public String getMessage() {

	    return message;

	  }
	  public String getDetails() {

	    return details;

	  }

	}