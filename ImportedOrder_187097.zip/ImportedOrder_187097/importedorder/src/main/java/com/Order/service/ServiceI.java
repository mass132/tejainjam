package com.Order.service;

import java.util.List;
import java.util.Optional;

import com.Order.entities.Order;

public interface ServiceI {

	List<Order> createOrder(Order ord);
	
	List<Order> viewAllOrder();       //In  order to display all orders
	
	List<Order> updateOrder(Order ord);
	
	List<Order> findByQuantity(int quantity1,int quantity2);
	
	List<Order> findByAmount(double amount);
	

}
