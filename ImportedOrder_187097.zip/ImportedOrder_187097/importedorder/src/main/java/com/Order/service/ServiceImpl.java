package com.Order.service;
import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Order.entities.Order;
import com.Order.exceptions.GlobalException;
import com.Order.repository.DaoImpl;

@Service
public class ServiceImpl implements ServiceI {

	@Autowired
	DaoImpl ds;

	@Override
	public List<Order> createOrder(Order ord) {
		// TODO Auto-generated method stub
		double price = ord.getPrice();
		int quantity = ord.getQuantity();
		double amount = price * quantity * 75;
		double charges = amount * 1.25 / 100;
		
		ord.setAmount(amount);
		ord.setCharges(charges);
		
		ds.save(ord);
		
		return ds.findAll();
	}

	@Override
	public List<Order> viewAllOrder() {
		// TODO Auto-generated method stub
		return ds.findAll();
	}

	@Override
	public List<Order> updateOrder(Order ord) {
		if(ds.existsById(ord.getId())) {
			ds.save(ord);
			return ds.findAll();
		}
		
		return null;
	}

	@Override
	public List<Order> findByQuantity(int quantity1,int quantity2) {
		
		return ds.findByQuantity(quantity1,quantity2);
	}

	@Override
	public List<Order> findByAmount(double amount) {
		// TODO Auto-generated method stub
		return ds.findByAmount(amount);
	}
	
}
