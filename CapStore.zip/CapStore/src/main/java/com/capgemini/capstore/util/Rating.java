package com.capgemini.capstore.util;

public enum Rating {
	Poor, Okay, Good, VeryGood, Excellent;
}