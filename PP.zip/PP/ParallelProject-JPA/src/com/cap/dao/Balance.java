package com.cap.dao;

public class Balance extends RuntimeException {
	public Balance() {
		// TODO Auto-generated constructor stub
		super();
		System.out.println("enter valid amount");
		

	}
}
