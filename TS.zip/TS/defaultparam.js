function add(x, y, z) {
    if (z === void 0) { z = 0; }
    return x + y + z;
}
var result1 = add(2, 3);
var result2 = add(2, 3, 5);
console.log(result2);
