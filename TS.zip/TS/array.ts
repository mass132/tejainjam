var arr:[number,string];
var c:string;
arr=[1,"true"];
arr=[2,"false"];