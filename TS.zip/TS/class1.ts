class Employee{
    empid: number;
    name: string;

    constructor(empid: number, name: string, ){
        this.empid=empid;
        this.name=name;
    }
    displaydetails(){
        return this.empid + " "+this.name;

    }
}
var emp =new Employee(123, "pavan");
console.log(emp.displaydetails());
var emp1 =new Employee(123, "pavan");
console.log(emp1.displaydetails());
