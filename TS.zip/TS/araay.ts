let num=12;
let a1={1,2,3,4,'a',true};
var x :number[];
x={1,2,3,4};