function add(x:number, y: number, z : number =0):number{
    return x+y+z;
}
let result1=add(2,3);
let result2=add(2,3,5);
console.log(result2);