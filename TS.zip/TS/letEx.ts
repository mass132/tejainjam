let yes:boolean=true;
let no:boolean=false;
let a: String="pavan";
let b:String ="pk";
console.log(a);