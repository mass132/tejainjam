var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Person1 = /** @class */ (function () {
    function Person1(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    Person1.prototype.fullname = function () {
        return this.firstname + " " + this.lastname;
    };
    return Person1;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(_id, firstname, lastname) {
        var _this = _super.call(this, firstname, lastname) || this;
        _this.id = _id;
        return _this;
    }
    Employee.prototype.showdetails = function () {
        console.log(this.id + " " + this.fullname());
    };
    return Employee;
}(Person1));
var e1 = new Employee(1, "pavan", "ll");
e1.showdetails();
