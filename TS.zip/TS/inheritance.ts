class Person1{
    private firstname: string;
    private lastname: string;
    constructor(firstname:string,lastname:string){
        this.firstname=firstname;
        this.lastname=lastname;
    }
    fullname(): string{
        return this.firstname + " "+ this.lastname;
    }
}
class Employee extends Person1{
    id: number;
    constructor(_id:number, firstname: string, lastname :string){
        super(firstname,lastname);
        this.id=_id;
    }
        showdetails():void
        {
       console.log(this.id+" "+this.fullname());

        }
    }
    let e1=new Employee(1,"pavan","ll");
    e1.showdetails();

