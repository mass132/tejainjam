class Person2{
firstname;
lastname;

constructor(firstname:string,lastname:string)
{
this.firstname=firstname;
this.lastname=lastname;
}
}
var p=new Person2("capgemini","chennai");
console.log(p.firstname+ " "+p.lastname);



