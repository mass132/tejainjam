function add() {
    var x = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        x[_i] = arguments[_i];
    }
    var result = 0;
    for (var i = 0; i < x.length; i++) {
        result += x[i];
    }
    return result;
}
var nums = [2, 3, 4];
var result = add(2, 3, 4, 12);
console.log(result);
