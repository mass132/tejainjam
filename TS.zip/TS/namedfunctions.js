function add(x, y) {
    return x + y;
}
var sum = function (x, y) {
    return x + y;
};
add(10, 15);
sum(12, 15);
var sum1 = function (x, y) { return x + y; };
console.log(add(10, 15));
sum1(100, 200);
var sum2 = function (x, y) { return x + y; };
sum2(100, 200);
console.log(sum2(100, 200));
var sum3 = function (x, y) { return x + y; };
sum3(1000, 200);
console.log(sum3(1000, 200));
var sum4 = function () { return console.log("function without return type"); };
sum4();
