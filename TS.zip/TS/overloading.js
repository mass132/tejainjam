function add(x, y, z) {
    var result;
    if (typeof x == "number" && typeof y == "number" && typeof z == "number") {
        result = x + y + z;
    }
    else {
        result = x + y + " " + z;
    }
    return result;
}
var result1 = add(9, 3, 8);
console.log(result1);
var result2 = add("welcome", "hello", "hy");
console.log(result2);
