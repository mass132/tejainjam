var Employee1 = /** @class */ (function () {
    function Employee1(empid, name) {
        Employee1.empid = empid;
        this.name = name;
    }
    Employee1.prototype.displaydetails = function () {
        return Employee1.empid + " " + this.name;
    };
    return Employee1;
}());
Employee1.empid = 1212;
var emp = new Employee1(123, "pavan");
console.log(emp.displaydetails());
