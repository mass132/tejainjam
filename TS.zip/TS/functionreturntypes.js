function addition(a, b) {
    return a + b;
}
var sum = addition(10, 20);
var sum1 = addition('kl', 25);
console.log(sum);
var x;
function addition1(a, b) {
    return a + b;
}
var sum4 = addition1(100, 200);
function add2(a, b, c) {
    return a + b + c;
}
var sum2 = add2(100, 200, 35);
var sum3 = add2(100, 200, 230);
console.log(sum2);
console.log(sum3);
function add3(a, b, c, d) {
    return a + b + c + d;
}
