class Employee1{
    static empid: number;
    name: string;
    constructor(empid: number, name: string, ){
        Employee1.empid=empid;
        this.name=name;
    }
    displaydetails(){
        return Employee1.empid + " "+this.name;

    }
}
Employee1.empid=1212;
var emp =new Employee1(123, "pavan");
console.log(emp.displaydetails());

