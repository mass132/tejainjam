var Person2 = /** @class */ (function () {
    function Person2(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    return Person2;
}());
var p = new Person2("capgemini", "chennai");
console.log(p.firstname + " " + p.lastname);
