var Person = /** @class */ (function () {
    function Person() {
    }
    return Person;
}());
var p = new Person();
p.firstname = "pavan";
p.lastname = "kalyan";
console.log(p.firstname + " " + p.lastname);
