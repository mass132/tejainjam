function add(x: number, y: number): number{
return x+y;
}
let sum =function(x:number, y: number):number{
    return x+y;
};
add(10,15);
sum(12,15);
let sum1=(x:number,y:number)=>x+y;
console.log(add(10,15));
sum1(100,200);
let sum2=(x:number,y:number)=>{return x+y};
sum2(100,200)
console.log(sum2(100,200));
let sum3=(x,y)=>x+y;
sum3(1000,200);
console.log(sum3(1000,200));
let sum4=()=>console.log("function without return type");
sum4();
