var Employee = /** @class */ (function () {
    function Employee(empid, name) {
        this.empid = empid;
        this.name = name;
    }
    Employee.prototype.displaydetails = function () {
        return this.empid + " " + this.name;
    };
    return Employee;
}());
var emp = new Employee(123, "pavan");
console.log(emp.displaydetails());
var emp = new Employee(123, "pavan");
