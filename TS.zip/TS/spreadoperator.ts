function add(...x: number[]): number{
    let result =0;
    for (var i=0;i<x.length;i++){
        result+=x[i];
    }
    return result;
}
let nums: number[]=[2,3,4];
let result =add(2,3,4,12,);
console.log(result);