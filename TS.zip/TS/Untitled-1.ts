var a=10;
var b=true;
var s="pavan";
function greet():string
{
    return "hello! good morning";

}
var greeting =greet();
var greeeting;
greeeting=greet();
console.log(greeting);
function greet1(){
    return "hello! good morning";
}
var greeeting;
greeting =greet1();
console.log(greeting);