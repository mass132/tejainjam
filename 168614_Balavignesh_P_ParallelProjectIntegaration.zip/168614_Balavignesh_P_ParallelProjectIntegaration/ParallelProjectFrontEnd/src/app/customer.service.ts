import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  http:HttpClient;
  isLogin:boolean=true;
  customers:Customer[]=[];
  transactions:Transactions[]=[];
  fetched:boolean=false;
  fetchedT:boolean=false;
  loginAccount:number=0;
  
  private check = new BehaviorSubject('');
  currentMessage = this.check.asObservable();

  changeMessage(message: string) {
    this.check.next(message)
  }

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchCustomers();
  }

  fetchCustomers()
  {
    this.http.get('http://localhost:9874/xyz/showAllAccounts').subscribe(data=>{this.convert(data)});
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Customer(o.caccount,o.cname,o.cphone,o.cpassword,o.cbalance);
      this.customers.push(e);
    }
  }


  getCustomers():Customer[]
  {
    return this.customers;
  }

  miniStatement(caccount:number):Observable<any>{
    return this.http.get("http://localhost:9874/xyz/print/"+caccount);
  }

  add(cname:string,cphone:number,cpassword:string,cbalance:number):Observable<any>
  {
    var customer = {
      "cname":cname,
      "cbalance" :cbalance,
      "cpassword":cpassword,
      "cmobile": cphone
    }
    return this.http.post("http://localhost:9874/xyz/create/",customer)
  }

  showBalance(caccount_first:number):Observable<any>
  {
    return this.http.get("http://localhost:9874/xyz/showBalance/"+caccount_first+"/")
  }

  depositeBalance(caccount_first:number,cbalance:number):Observable<any>
  {
    return this.http.put("http://localhost:9874/xyz/deposit/"+caccount_first+"/"+cbalance,null)
  }

  withdrawBalance(caccount_second:number,cbalance:number):Observable<any>
  {
    return this.http.put("http://localhost:9874/xyz/withdraw/"+caccount_second+"/"+cbalance,null)
  }

  fundTransfer(caccount_first:number,cbalance:number,caccount_second:number):Observable<any>
  {
    return this.http.put("http://localhost:9874/xyz/fundTransfer/"+caccount_first+"/"+cbalance+"/"+caccount_second,null)
  }

  login(data:Customer):boolean
  {
    this.loginAccount=data.caccount;
    let cpassword=data.cpassword;

    for(let a of this.customers)
    {
      console.log(this.customers)
      if(this.loginAccount == a.caccount && cpassword == a.cpassword)
      {
       
        alert("Value Matched!")
        this.isLogin=!this.isLogin;
        this.changeMessage('loginhai');
        return true;
      }else {
        continue;
      }
    }
    return false; 
  }

}

export class Customer{
  caccount:number;
  cname:string;
  cphone:number;
  cpassword:string;
  cbalance:number;

    constructor(caccount:number,cname:string,cphone:number,cpassword:string,cbalance:number)
    {
      this.cbalance=cbalance;
      this.caccount=caccount;
      this.cname=cname;
      this.cphone=cphone;
      this.cpassword=cpassword;
    }
}

export class Transactions{
  tid:number;
  taccount_sender:number;
  taccount_reciver:number;
  tamount:number;
  ttype:string;
    constructor(tid:number,taccount_sender:number,taccount_reciver:number,tamount:number,ttype:string)
    {
      this.tid=tid;
      this.taccount_sender=taccount_sender;
      this.taccount_reciver=taccount_reciver;
      this.tamount=tamount;
      this.ttype=ttype;
    }
}